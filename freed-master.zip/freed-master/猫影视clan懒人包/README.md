# 猫影视TV 2.1.1 BETA6 新功能
本地接口 clan://协议 简易设定流程：
* 下载底下懒人包 并记住存放位置
* 升级猫影视TV至 2.1.1 Beta6
* 设置 --> 存储权限 --> 允许
* 设置 --> 当前接口配置 --> 透过扫码或浏览器访问网址 (如 http://172.16.xx.xx:9978/api.html)
* 假设你已透过上述方式，成功进入"猫影视.接口"配置页面
	* 配置 --> 上传文件 --> 长按刚刚下载的懒人包 选取 --> 开启 --> 确认上传? --> 确定
* 回到猫影视TV --> 设置 --> 当前接口配置 --> 直接黏贴底下懒人包相对应的配置接口设定 --> 确定 --> 躺平

P.S
* 同一懒人包(文件名称不变)，重复上传的话，新的设定&文件 会覆盖掉旧的
* 同理 如懒人包有更新(文件名称不变)，只要下载并透过上述教学，重新上传一次，就算是更新了

# [唐三大佬]
* 下载懒人包：[Tangsan99999.zip](https://github.com/YuanHsing/freed/raw/master/猫影视clan懒人包/Tangsan99999.zip)
* 配置接口：clan://localhost/tangsan99999/xiaobai.json


# [beddychen大佬]
* 下载懒人包：[baddychen0608.zip](https://github.com/YuanHsing/freed/raw/master/猫影视clan懒人包/baddychen0608.zip)
* 配置接口：clan://localhost/baddychen0608/baddychen0608.json


# [小明大佬]
* 下载懒人包：[xm.zip](https://github.com/YuanHsing/freed/raw/master/猫影视clan懒人包/xm.zip)
* 配置接口：clan://localhost/xm/xm.json
