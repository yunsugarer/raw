# [影视]

## 1. 海阔视界
* 海阔视界｜APP
  + [APP载点1](https://www.lanzoux.com/u/GoldRiver) / [APP载点2](https://www.lanzoui.com/u/GoldRiver)
  + [更新，下一次不知道什么时候了](https://mp.weixin.qq.com/s/U12jFQQN5R2-8GONrvSbDA)
  + [这次升级能打三个！](https://mp.weixin.qq.com/s/f7U_G49s5nNc9tWc93H3RA)
  + [更新，聚云盘Pro版来了！](https://mp.weixin.qq.com/s/nAgBLNPrOEzLfSAiyrpurA)
  + [更新，这次累得够呛！](https://mp.weixin.qq.com/s/L57htcwCo27DuumxGGI7VA)
  + [新版更新，五一特版！](https://mp.weixin.qq.com/s/fTN7jd1gALpW4YlxEq1y3Q)
  + [更新，必更，有大招！](https://mp.weixin.qq.com/s/3g8_nYnr11oIG8XVR8tSZw)
  + [更新，嗅探和下载全面增强](https://mp.weixin.qq.com/s/CnP5Lm-fpXdylWmYLssmCw)
  + [更新，边下边播太舒服了！](https://mp.weixin.qq.com/s/-cH8kro4HpDa4pF3iHTBJg)
  + [更新，边下边播模式来了！](https://mp.weixin.qq.com/s/1gAlRAwqYkLWjOfL_gdg7Q)

* 海阔视界｜小程序：
  + 设置 > 剪贴板口令导入 > 贴上 > ok
  + 小程序源合集更新：
    + [4月合集](https://mp.weixin.qq.com/s/Uz3OIr8uJWr2xlxz8W8VkA) / [5月合集](https://mp.weixin.qq.com/s/OSHRfwN8r_n0MvD55_CuaQ)
  + [发两个优质APP规则](https://mp.weixin.qq.com/s/dB3XA0QLrRnyTPT6oKR47g)
  + [地址被屏蔽了](https://mp.weixin.qq.com/s/2JhbK3dvl9R8TuDHi1i27A)
  + [一键复活优质规则！](https://mp.weixin.qq.com/s/zZvqc12iC9j5eeUctvhhRA)
  + [汇聚五大平台免费用，已做成规则！](https://mp.weixin.qq.com/s/Hfjv4ou-zR_V9at9KBsVvg)
  + [毒盘君出炉，大家一起来分享吧！](https://mp.weixin.qq.com/s/sz4lLGfFN__bTkR7JFl0fQ)
  + [资源轻合集更新，集众多软件！](https://mp.weixin.qq.com/s/CBAShyn2z2hI_BqVPADV_Q)
  + [这次来几个国产的，规则分享第N期！](https://mp.weixin.qq.com/s/Vt-q_3KHDsjEMMtAqTgj9w)
  + [用心直播更新，升级若干源](https://mp.weixin.qq.com/s/qK6YyHzFFsrhDWHDFaQo-w)
  + [三个规则升级，推荐尽快导入](https://mp.weixin.qq.com/s/pcLYyfC6muXIC4ioD6r-Zw)
  + [大招来了，新一代APP聚搜](https://mp.weixin.qq.com/s/hx9kCuDK_jGdqT7h4oqsQg)
  + [这次是真的一键生成小程序！](https://mp.weixin.qq.com/s/CdSvrBr-QUzMzktvZ8iZaQ)
  + [最新魔改分享，我的聚直播没用了！](https://mp.weixin.qq.com/s/4os3AT4i3WGtuIGuoJoxAw)
  + [一键出规则，还支持视频嗅探！](https://mp.weixin.qq.com/s/hQ2bOJwBQ8I9pTQS1v63Qg)
  + [超高清晰度，你肯定喜欢！](https://mp.weixin.qq.com/s/NQp_4tC-e89glNfmtG3kiw)

* 海阔视界｜Q&A：
  + [海阔视界纯新人上手使用指南（保姆级）](https://www.bilibili.com/video/BV1YN411Q7Ho)
  + [海阔视界常见问题系列（一）](https://mp.weixin.qq.com/s/ukMZ4D6eRm-OCAR1G8PaoQ)
  + [海阔视界常见问题（二）](https://mp.weixin.qq.com/s/Jp3Xn8IqapQhEJIz5DCY8A)


## 2. 猫影视TV
* 猫影视TV｜APP
  + https://github.com/catvod/CatVodTVSpider
* 猫影视TV｜接口
  + 设置 > 当前配置接口
* 猫影视TV｜接口相关
  + https://github.com/catvod/CatVodTVSpider/tree/master/jar
  + https://github.com/catvod/CatVodTVSpider/blob/master/XPath.md
  + https://catvod.github.io/CatVodTVJsonEditor/
  + https://netcut.cn/

## 3. FreeDTV
* FreeDTV｜APP
  + https://github.com/FreeDTV/FreeD
  + [APP载点](https://www.lanzoui.com/b025mpw7e)
  + [TV版本1.2.3开放自定义解析](https://mp.weixin.qq.com/s/m_edUfPP5VuWSdVzaSdO8A)
  + [TV1.2.2搜索以及定制导航支持某类json格式接口](https://mp.weixin.qq.com/s/C2NCGvk0LUxDGa_ocilOtA)
* FreeDTV｜TV自建接口：( 自建接口 > 贴上 > 确定 > 重启APP )

      https://github.com/YuanHsing/freed/raw/master/tv/
* FreeDTV｜手机自建接口：

      https://github.com/FreeDTV/FreeD/raw/master/mobile/

## 4. ZY-Player-PC
* ZY-Player-PC｜APP

  https://github.com/cuiocean/ZY-Player
* ZY-Player-Android｜APP

  https://github.com/cuiocean/ZY-Player-APP
* 设置 > 编辑源 > 导入
___
# [小說]
## 1. 开源阅读📖 [[TG官方群](https://t.me/yueduguanfang) / [官网](https://www.legado.top/) / [博客](https://www.legado.top/blog)]
* 开源阅读📖｜APP
  + https://github.com/gedoor/legado/releases/
  + [完结](https://mp.weixin.qq.com/s/lO3knEMeai13WNpQkLpoeQ)
  + [20年](https://mp.weixin.qq.com/s/ZtmIw0A6Kw0zR7ckZzqObA)
  + [网页版/苹果版【阅读】使用教程](https://mp.weixin.qq.com/s/KPpnPxogVZgUqhOXa4o7kw)
  + [聊点深的](https://mp.weixin.qq.com/s/Hluv7IHe3TO6ex8pcc-e8w)
  + [说一下这个功能](https://mp.weixin.qq.com/s/D4rj5N3drFVyG2fYf0hMlw)
* 开源阅读📖｜书源合集更新【2022.05月】
  + 书源更新
    + [五月书源更新](https://www.legado.top/blog/book-source) (手机如有安装 开源阅读📖APP,该网站支援 "一键点击导入书源")
  + namofree大佬的书源（通用，精简，比较适合大多数人）：
      1. 修复失效书源，个别书源不错但总抽风的保留观察；
      2. 重新收录超星图书、九九藏书、稻草人出版书源；
      3. 起点排行榜、纵横排行榜、追书排行榜仅适用于找书，阅读时建议换源；
      4. 有的书源可能因为网络运营商问题导致不能访问的，建议换源；
      5. 本书源适用于3.0版，2.0版阅读app应该大部分都能用，但不保证全部适用；
      6. 每次导入之前建议把之前的Namo分组删除全新导入！

        https://namofree.gitee.io/yuedu3/legado3_booksource_by_Namo.json
  + 一程大佬：
    + 书源合集（通用，精简，比较适合大多数人）：
        1. 【修复】：笔趣阁②、番茄小说、书仓网、黑洞小说、第一版主、九桃小说、思路客④、墨坛文学、闪文书库、修笔小说、山药小说、顶点小说⑤、版主quest、瑶池小说
        2. 【新增】：有度、铅笔、92k、免费小说、笔下①、百书楼、爱巴士、菜皮、牧归、幻想姬、乡村、版主+、第二书包、天籁+、值得阅读、爱阅、阅爱、阅民
        3. 【删除】：其他>版主+、笔趣阁（PC版）、搜小说、努努书坊、八一中文②、大众小说、爱看书吧①、免费搜书、追更小说、书本网
        4. 移除漫画分类（漫画源以后放到订阅源里了）
        5. 提示 建议删除旧书源后再导入。

          https://e-c.coding.net/p/yicheng/d/YD/git/raw/master/sy.json
    + 订阅源：
        1. 【修复】：媒体>涨姿势、游戏时光、凤美收音机、盐酸小姐、AC正义，阅读>名言通
        2. 【新增】：媒体>生活、日报、期刊、资讯，阅读>有声、故事、阅读、下书、小说、玄学，资源>搜索、网盘、百科、工具、游戏、字体、萌宠、直播
        3. 【删除】：媒体>游戏大观
        4. 已将影视融合到资源

          https://e-c.coding.net/p/yicheng/d/YD/git/raw/master/dy.json
  + 破冰大佬：
    + 3.0书源总合集网络：

          https://pbpobing.coding.net/p/yueduyuan/d/sy/git/raw/master/3.0shuyuan.json
    + 3.0精选合集(偶尔更新)：

          https://pbpobing.coding.net/p/yueduyuan/d/sy/git/raw/master/50.json
    + 3.0笔趣阁合集(偶尔更新)：

          https://pbpobing.coding.net/p/yueduyuan/d/sy/git/raw/master/bqg.json
    + 有声源合集(没问题不更新)：

          https://pbpobing.coding.net/p/yueduyuan/d/sy/git/raw/master/3.0yousheng.json
  + haxc大佬的精选漫画源：
  
        https://haxc.coding.net/p/booksrc/d/booksrc/git/raw/master/bookSource.json
  + 关耳大佬的女频书源：
  
        https://guaner001125.coding.net/p/coding-code-guide/d/booksources/git/raw/master/sources/guaner.json
  + 再次提醒大家，选择1-2位大佬的一直追更就行，没必要全部导入。

* 开源阅读📖｜其它书源
  + https://github.com/XIU2/Yuedu
  + http://yck.mumuceo.com/yuedu/shuyuan/index.html
  + http://yuedu.miaogongzi.net/gx.html


## 2. 香色闺阁
* ios版～支持书源导入～无广告、无内购
* 香色闺阁｜APP
  * https://apps.apple.com/cn/app/id1521205149
* 香色闺阁｜书源
  * (书源管理>同步>搜索书源) 或 (书源管理>同步>粘贴 新书源>同步)
    ```
    https://flyandnewgame.coding.net/p/a/d/xs/git/raw/master/source.xbs
    ```
    ```
    https://gitee.com/giovannyramsey/xiangse/raw/master/sourceModelList.xbs
    ```
    ```
    https://raw.githubusercontent.com/dejiayuan/xiangse/main/sourceModelList.xbs
    ```
    ```
    https://alphonsoestrada.coding.net/p/test/d/xiangse/git/raw/master/sourceModelList.xbs
    ```
    ```
    https://alphonsoestrada.coding.net/p/test/d/xiangse/git/raw/master/sourceModelList2.xbs
    ```
    ```
    https://gitee.com/readbook188/xiangs/raw/master/sourceModelList.xbs
    ```
    ```
    https://aliyabates.coding.net/p/xs/d/xs/git/raw/master/sourceModelList.xbs
    ```
    ```
    https://weilaiba.coding.net/p/s/d/s/git/raw/master/sourceModelList.xbs
    ```

* 香色闺阁｜书源｜香色闺阁益达源
  * https://github.com/xiaohucode/xiangse
* 香色闺阁｜书源｜搬运备份
  * https://github.com/zqzess/MyWebStorage/tree/main/xsreader/backup



## 3. 花火阅读
* ios版~支持阅读3.0书源导入
* 花火阅读｜APP
  * https://apps.apple.com/cn/app/id1546631588

## 4. 源阅读
* ios13版~支持阅读3.0书源导入
* 源阅读｜APP
  * https://github.com/kaich/Yuedu
  * https://apps.apple.com/cn/app/源阅读/id1561787704

___
# [漫画]
## 1. Tachiyomi｜APP
* Tachiyomi｜APP
  * https://github.com/tachiyomiorg/tachiyomi
  * https://github.com/tachiyomiorg/tachiyomi/releases
* tachiyomi-preview｜APP
  * https://github.com/tachiyomiorg/tachiyomi-preview
  * https://github.com/tachiyomiorg/tachiyomi-preview/releases
* Tachiyomi｜安装书源
  * 浏览 > 扩展插件 > 安装 (一个一个安装)
* Tachiyomi｜找漫画
  * 书架 > 搜寻
  * 浏览 > 扩展插件 > 来源
* Tachiyomi｜开启平板电脑介面
  * 设定 > 进阶 > 检视 > 强制使用平板电脑介面 > 立即 或 横向

## 2. Cimoc
* Cimoc｜APP
  * https://github.com/Haleydu/Cimoc
  * [Cimoc版本1.7.73](https://mp.weixin.qq.com/s/2HxcLynae7UQMCe-ldlyfw)
* 导入图源 > 粘贴 >

      https://gitee.com/Haleydu/update/raw/master/sourceBaseUrl.json

## 3. cilidili (Cimoc IOS版本，已下架)
* cilidili｜介绍
  * [cimoc的ios版本已上架成功](https://mp.weixin.qq.com/s/fOFuOC6u2HS75jfyznPGXw)
* cilidili｜图源

      http://www.cimoc.top/source.json

## 4. 异次元
* 异次元｜APP
  * https://yiciyuan.lanzoux.com/b00ej0kba
  * [2.3.9版本，快来更新吧！](https://mp.weixin.qq.com/s/ctrOvlhHFSIUczOI--NW9A)
  * [2.3.7版本，进尽快更新](https://mp.weixin.qq.com/s/EzQflhgUhthjUkP3nOXoAw)
* 异次元｜图源
  * 此次更新是大整合源更新，记得全删除后再导入，更新到最新版本软件使用！！！
  * [2022.05.15 无图标大整合源更新](https://mp.weixin.qq.com/s/CK4XuI8Z8XEWQZ4T_YJQRg)
  * [2022.05.15 有图标大整合源更新](https://mp.weixin.qq.com/s/eyzaGFkUcbuBfyTBWSDv4g)
  * https://github.com/wanglabk/hub/tree/c2099
  * http://yck.mumuceo.com/yiciyuan/tuyuan/index.html

___
# [WebDav＆数据备份与同步]
* 授权教程
  * https://help.jianguoyun.com/?p=2064
* 申请网站
  * https://www.jianguoyun.com/
* 设定步骤
  * 账户信息 > 安全选项 > 第三方应用管理 > 添加应用 > 名称 > 生成密码
* WebDav地址

      https://dav.jianguoyun.com/dav/
